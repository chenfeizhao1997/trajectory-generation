import numpy as np
from PathPlanning import RRTStar, Map
from TrajGen import trajGenerator, Helix_waypoints, Circle_waypoints
np.random.seed(7)

# 3D boxes   lx, ly, lz, hx, hy, hz
obstacles = [
             # [45, 35, 0, 55, 60, 60],
             [10, 10, 0, 60, 60, 100],
             # [70, 50, 0, 80, 80, 100]
            # [30,30,0,70,70,100]
            ]

# limits on map dimensions
bounds = np.array([0,150])
# create map with obstacles
mapobs = Map(obstacles, bounds, dim = 3)

#plan a path from start to goal
start1 = np.array([0,0,20])
goal1 = np.array([70,60,60])

rrt1 = RRTStar(start = start1, goal = goal1,
              Map = mapobs, max_iter = 8000,
              goal_sample_rate = 0.1)

waypoints1, min_cost1 = rrt1.plan()

start2 = np.array([-5,5,20])
goal2 = np.array([60,70,60])

rrt2 = RRTStar(start = start2, goal = goal2,
              Map = mapobs, max_iter = 8000,
              goal_sample_rate = 0.1)
waypoints2, min_cost2 = rrt2.plan()
#plot the waypoints and obstacles
rrt1.draw_scene(waypoints1, ax= None)
rrt2.draw_scene(waypoints2, ax= None)
#Generate trajectory through waypoints
waypoints = np.vstack((waypoints1, waypoints2[::-1]))
waypoints = np.insert(waypoints, len(waypoints), values=waypoints[0], axis=0) # add the start1 to form a circle
waypoints = np.insert(waypoints, len(waypoints), values=np.append(waypoints[1][:2]*0.5 , (waypoints[1][2] + waypoints[0][2]) * 0.5), axis=0) # add the second point in waypoints1 to make the start point smoother
waypoints = waypoints * 0.02 #scaling the tragectory to whatever we want
traj = trajGenerator(waypoints, max_vel = 1, gamma = 1e6)

#initialise simulation with given controller and trajectory
Tmax = traj.TS[-1]

t = np.arange(0,Tmax + 0.01,0.01)
pose = [] #record the position
vele = [] #record the velocity
accl = [] #record the acceleration
for i in t:
   p,v,a =traj.get_des_state(i)
   pose.append(p)
   vele.append(v)
   accl.append(a)
pose = np.array(pose)#position matrix
vele = np.array(vele)#velocity matrix
accl = np.array(accl)#acc matrix
para = np.hstack((pose, vele, accl))
para_delete = para[:650]
# np.savetxt("para.txt", np.array(para), delimiter =", ")
np.save('para.npy',np.array(para_delete))
import matplotlib.pyplot as plt
fig = plt.figure()
ax = fig.gca(projection='3d')
x = pose[:,0]
y = pose[:,1]
z = pose[:,2]
ax.plot(x, y, z, label='parametric curve')
ax.legend()
plt.show()